package com.example.actionmain;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.app.Fragment;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by 컴퓨터공학과 우하진 on 2016-12-03.
 */

public class Wf extends Fragment {

    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        View view = inflater.inflate( R.layout.w_f, container, false );
        return view;
    }
}